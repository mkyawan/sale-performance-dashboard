// Fictional sample data. Replace with authorized business figures before use.
const data=[
{m:"Jan",n:"Ayesha",l:82,e:58,d:12,r:540000,t:650000},{m:"Jan",n:"Bilal",l:74,e:51,d:10,r:465000,t:600000},{m:"Jan",n:"Hamza",l:68,e:43,d:8,r:390000,t:550000},
{m:"Feb",n:"Ayesha",l:91,e:66,d:15,r:690000,t:700000},{m:"Feb",n:"Bilal",l:79,e:55,d:11,r:510000,t:620000},{m:"Feb",n:"Hamza",l:72,e:49,d:9,r:440000,t:580000},
{m:"Mar",n:"Ayesha",l:96,e:70,d:17,r:760000,t:750000},{m:"Mar",n:"Bilal",l:85,e:60,d:13,r:625000,t:650000},{m:"Mar",n:"Hamza",l:77,e:52,d:10,r:490000,t:600000},
{m:"Apr",n:"Ayesha",l:88,e:64,d:14,r:650000,t:750000},{m:"Apr",n:"Bilal",l:92,e:67,d:15,r:710000,t:700000},{m:"Apr",n:"Hamza",l:81,e:56,d:11,r:530000,t:620000},
{m:"May",n:"Ayesha",l:103,e:76,d:19,r:880000,t:800000},{m:"May",n:"Bilal",l:94,e:69,d:16,r:745000,t:720000},{m:"May",n:"Hamza",l:86,e:61,d:13,r:620000,t:650000},
{m:"Jun",n:"Ayesha",l:98,e:72,d:18,r:820000,t:800000},{m:"Jun",n:"Bilal",l:101,e:74,d:17,r:790000,t:750000},{m:"Jun",n:"Hamza",l:89,e:63,d:14,r:680000,t:680000}];
const $=id=>document.getElementById(id), money=v=>"PKR "+Math.round(v).toLocaleString("en-PK");
[...new Set(data.map(x=>x.n))].forEach(n=>{let o=document.createElement("option");o.value=n;o.textContent=n;$("rep").append(o)});
let monthlyChart,teamChart;
function total(a,k){return a.reduce((s,x)=>s+x[k],0)}
function render(){
 const a=data.filter(x=>($("month").value==="all"||x.m===$("month").value)&&($("rep").value==="all"||x.n===$("rep").value));
 const rev=total(a,"r"),tar=total(a,"t"),leads=total(a,"l"),deals=total(a,"d"),ach=tar?rev/tar*100:0,conv=leads?deals/leads*100:0;
 $("revenue").textContent=money(rev);$("target").textContent=money(tar);$("achievement").textContent=ach.toFixed(1)+"%";$("conversion").textContent=conv.toFixed(1)+"%";
 const names=[...new Set(a.map(x=>x.n))], byName=names.map(n=>a.filter(x=>x.n===n));
 $("rows").innerHTML=names.map((n,i)=>{let b=byName[i],r=total(b,"r"),t=total(b,"t");return `<tr><td>${n}</td><td>${total(b,"l")}</td><td>${total(b,"e")}</td><td>${total(b,"d")}</td><td>${money(r)}</td><td>${money(t)}</td><td>${t?(r/t*100).toFixed(0):0}%</td></tr>`}).join("");
 const months=["Jan","Feb","Mar","Apr","May","Jun"].filter(m=>a.some(x=>x.m===m)), vals=months.map(m=>total(a.filter(x=>x.m===m),"r"));
 if(monthlyChart)monthlyChart.destroy();if(teamChart)teamChart.destroy();
 monthlyChart=new Chart($("monthly"),{type:"line",data:{labels:months,datasets:[{data:vals,label:"Revenue",borderColor:"#5369d8",backgroundColor:"rgba(83,105,216,.12)",fill:true,tension:.3}]},options:{plugins:{legend:{display:false}},scales:{y:{ticks:{callback:v=>(v/1000000).toFixed(1)+"M"}}}}});
 teamChart=new Chart($("team"),{type:"bar",data:{labels:names,datasets:[{data:byName.map(b=>total(b,"r")),backgroundColor:["#5369d8","#20a078","#e0a044"],borderRadius:6}]},options:{plugins:{legend:{display:false}},scales:{y:{ticks:{callback:v=>(v/1000000).toFixed(1)+"M"}}}}});
 const leader=names.sort((x,y)=>total(data.filter(z=>z.n===y&&a.includes(z)),"r")-total(data.filter(z=>z.n===x&&a.includes(z)),"r"))[0];
 $("insight").textContent=leader?`${leader} leads this filtered view with ${money(total(a.filter(x=>x.n===leader),"r"))} in revenue. Team target achievement is ${ach.toFixed(1)}%, and lead conversion is ${conv.toFixed(1)}%.`:"No records match the selected filters.";
}
$("month").addEventListener("change",render);$("rep").addEventListener("change",render);$("reset").addEventListener("click",()=>{$("month").value="all";$("rep").value="all";render()});render();