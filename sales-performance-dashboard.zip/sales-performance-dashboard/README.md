# Sales Performance & Revenue Dashboard

A responsive portfolio project built with HTML, CSS, vanilla JavaScript, and Chart.js. It demonstrates sales analytics, CRM-style reporting, revenue tracking, and team performance monitoring.

## Features
- Revenue, target, target achievement, and lead-conversion KPIs
- Monthly revenue trend and revenue-by-executive charts
- Executive performance table
- Month and executive filters
- Responsive desktop/mobile layout
- Sample CSV data

## Demo data
All names and figures are fictional and provided only for demonstration. Do not publish confidential customer or employer information.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Internet access is needed to load Chart.js from its CDN.

No build tools or installation are required.

## Customize
Edit the `data` array at the top of `app.js`. Each record contains month, executive, leads, engaged leads, deals won, revenue, and target. `data/sample-sales.csv` is a reference dataset; the app currently reads the JavaScript array, not the CSV file.

## Metrics
- Target achievement = revenue / target
- Lead conversion = deals won / leads
- Revenue contribution = closed-won revenue grouped by month or executive

## Technology
HTML5 · CSS3 · JavaScript · Chart.js

## Author
Mohammad Kashif — Sales & Business Development
